EMAIL="vasypupkintupol@gmail.com"
PASSWORD="Hitmanfz9"
REPO = "selenium-example"