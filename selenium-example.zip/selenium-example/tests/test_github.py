import time

from selenium import webdriver
from selenium.webdriver.common.by import By

from config import EMAIL, PASSWORD, REPO


def _login_in_profile(browser):
    browser.find_element(By.LINK_TEXT, "Sing in").click()
    time.sleep(2)
    browser.find_element(By.ID, "login_field").send_keys(EMAIL)
    browser.find_element(By.ID, "password").send_keys(PASSWORD)
    browser.find_element(By.NAME, "commit").click()


def test_create_and_delete_repository():
    browser = webdriver.Chrome()
    browser.get("https://github.com/")

    _login_in_profile(browser)
    browser.get("https://github.com/Save1ka")

    #creating repository
    browser.find_element(By.LINK_TEXT, "Repositories").click()
    time.sleep(1)
    browser.find_element(By.LINK_TEXT, "New").click()
    browser.find_element(By.ID, ":r2:").send_keys(REPO)
    browser.find_element(By.ID, ":r6:").click()
    browser.find_element(By.ID, ":r8:").click()
    time.sleep(2)
    browser.find_element(By.XPATH, '/html/body/div[1]/div[6]/main/react-app/div/form/div[5]/button').click()


    #checking after creating repo
    repo_name = browser.find_element(By.LINK_TEXT, "selenium-example")
    is_private = browser.find_element(By.XPATH, '//*[@id="repository-container-header"]/div[1]/div[1]/div[1]/span[2]')
    read_me = browser.find_element(By.LINK_TEXT, "README.md")

    assert repo_name.text == REPO
    assert is_private.text == "Private"
    assert read_me.text == "README.md"


    #delete repo
    browser.find_element(By.LINK_TEXT, "Settings").click()
    time.sleep(2)
    browser.find_element(By.ID, "dialog-show-repo-delete-menu-dialog").click()
    time.sleep(2)
    browser.find_element(By.ID, "repo-delete-proceed-button").click()
    time.sleep(2)
    browser.find_element(By.ID, "repo-delete-proceed-button").click()
    browser.find_element(By.ID, "verification_field").send_keys("Save1ka/selenium-example")
    browser.find_element(By.ID, "repo-delete-proceed-button").click()
    time.sleep(2)

    #checking after deleting
    message_info = browser.find_element(By.XPATH, '//*[@id="js-flash-container"]/div/div/div')

    assert message_info.text == 'Your repository "Save1ka/selenium-example" was successfully deleted.'

    browser.quit()
